import java.math.BigDecimal;

public class Posugac_Joshua_MidtermReq {

  public static BigDecimal exp(BigDecimal x, int scale) {
    // Handle base case (e^0 = 1)
    if (x.compareTo(BigDecimal.ZERO) == 0) {
      return BigDecimal.ONE;
    }

    BigDecimal result = BigDecimal.ONE;
    BigDecimal factorial = BigDecimal.ONE;
    for (int n = 1; n < 100; n++) { 
      factorial = factorial.multiply(new BigDecimal(n));
      BigDecimal term = x.pow(n).divide(factorial, scale, BigDecimal.ROUND_HALF_UP);
      result = result.add(term);
      
      if (term.abs().compareTo(BigDecimal.ZERO) < 0) {
        break;
      }
    }
    return result;
  }

  public static void main(String[] args) {
    BigDecimal x = new BigDecimal("2.25");
    int scale = 5; // Adjust scale for desired decimal places

    BigDecimal result = exp(x, scale);
    System.out.println("e^" + x + " = " + result);
  }
}