Exponential Function

Explanation: 
This code creates a function called exp with two parameters: x (the number to raise to a power) and scale (the number of decimal places in the result). 
If x is zero, the function returns BigDecimal.ONE as the base case. 
The function then uses the Taylor series to estimate e^x. 
It calculates each term by dividing x^n by n! (the factorial of n). 
To ensure the result has the desired number of decimal places, it uses the BigDecimal.ROUND_HALF_UP rounding mode during division. 
The loop continues iterating until a term becomes very small, indicating convergence. 
The final output is the approximation of e^x with the specified scale. 
The main function provides an example of how to use the exponential function with specific values for x and scale. 
Please note that this implementation relies on a Taylor series approximation.